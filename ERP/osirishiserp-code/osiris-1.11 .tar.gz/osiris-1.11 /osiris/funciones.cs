///////////////////////////////////////////////////////////
// project created on 24/10/2006 at 10:20 a
// Hospital Santa Cecilia
// Monterrey - Mexico
//
// Autor    	: Ing. Daniel Olivares (Programacion)
// 				  
// Licencia		: GLP
//////////////////////////////////////////////////////////
// Programa		: hscmty.cs
// Proposito	: funciones Varias para el sistemas 
// Objeto		: nn
//////////////////////////////////////////////////////////	
using System;
using Npgsql;
using System.Data;
using Gtk;
using Glade;
using Gnome;
using System.Collections;
using GtkSharp;

public class funciones
{
	    
	
	
	
}
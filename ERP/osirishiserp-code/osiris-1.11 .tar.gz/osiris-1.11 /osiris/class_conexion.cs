
using System;

namespace osiris
{
	class class_conexion
	{
		public string _url_servidor = "Server=localhost;";
        public string _port_DB = "Port=5432;";
        public string _usuario_DB = "User ID=admin;";
        public string _passwrd_user_DB = "Password=1qaz2wsx;";
		public string _nombrebd = "Database=osiris_preprod";
	}
}